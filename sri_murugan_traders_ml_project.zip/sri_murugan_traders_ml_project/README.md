# Predictive Analytics for E-Commerce

## Case Study
Sri Murugan Traders, Vellore

## Project
Sales Forecasting and Inventory Optimization Using Machine Learning.

## Files
- `main.py` - complete data analysis and ML forecasting pipeline
- `app.py` - dashboard placeholder
- `requirements.txt` - required Python packages
- `Sales Data for Sep 2025 to Sep 2026..xlsx` - sales dataset
- `Sales Return Data Sep 2025 to Sep 2026..xlsx` - sales return dataset

## Run in VS Code

```bash
pip install -r requirements.txt
python main.py
```

The program performs:
1. Data cleaning
2. Sales and returns analysis
3. Monthly and product-level analysis
4. Feature engineering
5. Random Forest forecasting
6. Gradient Boosting forecasting
7. Model comparison
8. 30-day sales forecasting
9. Demand-based safety stock and reorder-point calculation
10. Export of analysis results

### Important
The current datasets do not contain actual opening stock, closing stock, or purchase quantities. Therefore, the inventory calculation is demand-based. Actual inventory optimization should be added after those fields are obtained from the company.
